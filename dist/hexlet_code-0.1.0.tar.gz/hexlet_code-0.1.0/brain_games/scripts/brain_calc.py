#!/usr/bin/env python3


from brain_games.games.brain_calc import main as brain_calc


def main():
    brain_calc()


if __name__ == '__main__':
    main()
