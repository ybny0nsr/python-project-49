### Hexlet tests and linter status:
[![Actions Status](https://github.com/ybny0nsr/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/ybny0nsr/python-project-49/actions)
<a href="https://codeclimate.com/github/ybny0nsr/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/8387bd64d55abd7330a7/maintainability" /></a>

Демо сборки/публикации/установки
<a href="https://asciinema.org/a/673546" target="_blank"><img src="https://asciinema.org/a/673546.svg" /></a>

Демо brain-even
<a href="https://asciinema.org/a/674245" target="_blank"><img src="https://asciinema.org/a/674245.svg" /></a>

Демо brain-calc
<a href="https://asciinema.org/a/674246" target="_blank"><img src="https://asciinema.org/a/674246.svg" /></a>

Демо brain-gcd
<a href="https://asciinema.org/a/674247" target="_blank"><img src="https://asciinema.org/a/674247.svg" /></a>
