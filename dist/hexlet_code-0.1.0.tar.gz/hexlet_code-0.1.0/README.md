### Hexlet tests and linter status:
[![Actions Status](https://github.com/ybny0nsr/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/ybny0nsr/python-project-49/actions)
<a href="https://codeclimate.com/github/ybny0nsr/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/8387bd64d55abd7330a7/maintainability" /></a>
